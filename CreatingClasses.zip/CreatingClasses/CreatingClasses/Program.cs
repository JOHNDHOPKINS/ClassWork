﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreatingClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            Player player = new Player("Frankenstein");

            while (player.GetLivesLeft() > 0)
            {
                player.AddPoints(100);

                player.Kill();
            }
        }
    }
}
